<?php
    if( function_exists('epcl_render_reading_time') ){
        epcl_render_reading_time();
    }  
