<?php $epcl_theme = epcl_get_theme_options(); ?>
<?php if( epcl_get_option('logo_type') == 1 && !empty($epcl_theme['logo_image']['url']) ): ?>
    <div class="logo">
        <a href="<?php echo home_url('/'); ?>"><img src="<?php echo esc_url( $epcl_theme['logo_image']['url'] ); ?>" alt="<?php bloginfo('name'); ?>" width="<?php echo esc_attr( $epcl_theme['logo_width'] ); ?>" height="<?php echo esc_attr( $epcl_theme['logo_image']['height'] ); ?>"></a>
        <?php if( epcl_get_option('header_type') == 'classic' && epcl_get_option('logo_tagline', false) ): ?>
            <div class="tagline"><small><?php bloginfo('description'); ?></small></div>
        <?php endif; ?>
    </div>
    <?php if( !empty($epcl_theme['sticky_logo_image']['url']) ): ?>
        <div class="logo sticky-logo hide-on-mobile hide-on-tablet hide-on-desktop-sm">
            <a href="<?php echo home_url('/'); ?>"><img src="<?php echo esc_url( $epcl_theme['sticky_logo_image']['url'] ); ?>" alt="<?php bloginfo('name'); ?>" width="<?php echo epcl_get_option('sticky_logo_width'); ?>" /></a>
        </div>                
    <?php endif; ?>
<?php else: ?>
    <div class="logo text-logo">
        <a href="<?php echo home_url('/'); ?>" class="title ularge black no-margin">
            <?php if( isset( $epcl_theme['logo_icon'] ) && $epcl_theme['logo_icon'] ): ?>
                <span class="icon"><?php echo wp_kses( $epcl_theme['logo_icon'], get_kses_svg_ruleset() ); ?></span>
            <?php endif; ?>
            <span class="name"><?php bloginfo('name'); ?></span>
        </a>
        <?php if( epcl_get_option('header_type') == 'classic' && epcl_get_option('logo_tagline', false) ): ?>
            <div class="tagline"><small><?php bloginfo('description'); ?></small></div>
        <?php endif; ?>
    </div>
<?php endif; ?>